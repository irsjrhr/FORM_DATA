<?php 
require_once 'fungsi.php';
cek_sesi();


$user = $_SESSION['nama'];
$get_data = query("SELECT * FROM data_user WHERE user = '$user'");
$get_data = mysqli_fetch_assoc( $get_data );

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		Halaman Praktikum
	</title>
</head>
<body>

	<a href="index.php"> Index </a>
	<a href="coba.php"> Coba </a>
	<a href="logout.php"> Logout </a>

	<h1> SELAMAT DATANG <?= $get_data['nama'] ?> </h1>

</body>
</html>


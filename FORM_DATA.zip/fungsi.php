<?php 

session_start();

// $data = [
// 	[
// 		"user" => "shandy",
// 		'password' => "shandy123"
// 	],
// 	[
// 		"user" => "dada",
// 		'password' => "dada123"
// 	],
// 	[
// 		"user" => "didi",
// 		'password' => "didi123"
// 	]
// ];
$server = "localhost";
$user = "root";
$pass = "";
$db = "latihan";
$konek = mysqli_connect( $server, $user, $pass, $db );



function query( $sql ){
	global $konek;
	$query = mysqli_query( $konek, $sql );

	return $query;
}
function cek_sesi(){
	if ( !isset($_SESSION['nama']) ) {
		header('location:login.php');
	}
}

function buat_sesi(){
	$_SESSION['nama'] = "shandy";
}
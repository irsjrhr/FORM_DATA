<?php 
require_once 'fungsi.php';


// require_once 'index.php';
// // unset($_SESSION['nama']);

var_dump($_SESSION);
cek_sesi();


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		Halaman Praktikum
	</title>
</head>
<body>

	<a href="index.php"> Index </a>
	<a href="coba.php"> Coba </a>
	<a href="logout.php"> Logout </a>

	<h1> Halaman coba </h1>

</body>
</html>

